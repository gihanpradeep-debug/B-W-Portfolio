import { Project, ToolkitItem } from './types';

export const projectsData: Project[] = [
  {
    id: 'velocis-dashboard',
    title: 'Velocis Dashboard',
    category: 'Automotive',
    subtitle: 'Sleek futuristic electric supercar interface mockup',
    year: '2023',
    client: 'Velocis Motors',
    role: 'Lead UI/UX Architect',
    accentColor: '#4c5b71',
    description: 'A sleek, futuristic electric supercar dashboard interface mockup. Displays minimal telemetry data with elegant curved screen highlights.',
    longDescription: 'The Velocis Dashboard represents the pinnacle of human-machine interaction in high-performance electric vehicles. Designed for high responsiveness and situational awareness, the interface organizes complex engine diagnostics, state-of-charge parameters, and predictive navigation elements into a cohesive, high-luminance HUD. It minimizes visual strain while evoking the quiet power of high-end engineering.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCPcRORrtko_o8ZotbyAyeB4e-Odnf1zgXTj4il3GyXdcs_kgZeNvZ6FDXw0qPpp606Si1PaXMdhAtGRDpPtEvNZInS9Qh3ZwO4dOJpzxDU3cuKgB9DskZSNjJ7_m_lQNMQZahp4ouzCVhvH7Wie7swpnnxUZQfCqZsmUxVNAK9rYURuMenSGo36gJaYPRrVZ5G_08wrHNYbTZqYW9F2zWvsMP9CJl7VbG34gKLjXaUZRhcnRw6fS72hGjikIoOT_WEoICNd8Emy0g',
    tags: ['Automotive HMI', '3D UI Physics', 'Dark Vision', 'Telemetry Mapping'],
    challenges: 'Designing a dashboard for active racing conditions requires high legibility at 300+ km/h. Traditional gauges clutter peripheral vision. The primary challenge was removing non-essential dials while creating a dynamic warning overlay that responds instantly to battery thermal events and tire pressure deltas.',
    outcomes: [
      'Reduced operator reaction time to status warnings by 42% in simulation trials.',
      'Designed a proprietary high-contrast night vision mode mimicking aeronautical HUD setups.',
      'Perfected a zero-latency telemetry dashboard utilizing custom canvas rendering protocols.',
      'Awarded "Best HMI Concept of 2023" at the Automotive Tech Innovations Summit.'
    ]
  },
  {
    id: 'aura-banking',
    title: 'Aura Banking',
    category: 'Fintech',
    subtitle: 'Premium private banking app interface on a glass card canvas',
    year: '2024',
    client: 'Aura Premium Group',
    role: 'Principal Digital Designer',
    accentColor: '#1a1c1c',
    description: 'A premium banking interface presented on a sleek glass card. Prioritizes security and absolute semantic clarity using luxury typography.',
    longDescription: 'Aura Banking is an experiential financial management platform built for high-net-worth investors. Merging luxury physical aesthetics with fluid digital components, Aura treats client wealth management with absolute care. The application leverages soft glassmorphic visual cues, gold-accented visual charts, and a high-contrast layout that elevates everyday portfolio oversight into an elite lifestyle experience.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDSewtye9DY2amiDYh0AK3WaKiEP_yCjS5YIj6K2KiRZq7x8plYngMGu5hAFE_gFe888dbrTwMtUP68hRff9o-2KjcCPbpAUkrx_MQehQjnN1PyTjS5cYwpVus9OoOFsFRXP45QwBrV6OrlwL-dnvyVWMP-QsMj8TQjHpqGkQjNWbbDxNJL57xMTDbPi6IYtAvsoYzp_MmBwP-eHU7wSNF3oUPYG56ZXFSIgmEDaPv4WUetO1anARYsQS73jH9kNyKtKDFnAEDxySU',
    tags: ['Fintech UX', 'Glassmorphism', 'Data Vis', 'Micro-interactions'],
    challenges: 'High-end clients find traditional banking application layouts cluttered, generic, and transactional. We had to rethink how investment positions are visualised, condensing hundreds of active variables into actionable estate-building parameters.',
    outcomes: [
      'Created a bespoke digital luxury aesthetic that raised client onboarding NPS from +34 to +75.',
      'Co-developed an award-winning glass card custom shader library for fluid web interaction.',
      'Secured cross-browser performance under 1.2s for complex financial asset maps.',
      'Featured globally in DesignMilk and Typewolf for superior layout craftsmanship.'
    ]
  },
  {
    id: 'maison-noir',
    title: 'Maison Noir',
    category: 'E-commerce',
    subtitle: 'Editorial brand experience for high-end fashion design houses',
    year: '2022',
    client: 'Maison Noir Paris',
    role: 'Digital Art Director',
    accentColor: '#6f5636',
    description: 'An editorial e-commerce website for a luxury fashion house. Large high-contrast typography is framed by generous blank space.',
    longDescription: 'Maison Noir completely reimagines the luxury online retail environment. Instead of presenting products in grid boxes, the design treats the online catalog like an physical editorial lookbook. Combining elegant typography, high-fashion imagery, and an architectural grid layout, the site enables users to appreciate the tailoring, texture, and concept of each design item.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBsqSu1RcYNZB9QIdfFRiQP_6Pz1zaCU8hQdEtrgK1jdqjtML-tT4ysBNNdFjF85Sht1uKWFiQYi32S4Zl94tIorEqFcdv8psN2a5GZXclJ-e1CXULDkoJ6-aO0HOqt0RCRusET8owYkfVzmgfuZh6mbVOP5fmlXUnWcIezvUg-2vOBZz_a_tuJBeKBzVbVljgWiGzC1t7uKcs0l0ax9dAffUJPGWpRe4NqHD3CXeR-ZRwpOcgimZHGeOTuuMVPgM80Dl7-B0368k4',
    tags: ['Digital Lookbook', 'Editorial Grid', 'Interactive Canvas', 'Retail Systems'],
    challenges: 'Conventional retail layouts maximize immediate density, often reducing the premium nature of haute couture products. Our challenge was translating high fashion tactile quality into mobile-first web platforms without compromising page conversion performance.',
    outcomes: [
      'Maintained a premium lookbook aesthetic while improving average order value (AOV) by 38%.',
      'Engineered interactive custom transitions simulating smooth pages of an physical editorial magazine.',
      'Optimised heavy media delivery using customized next-generation media loading pipelines.',
      'Received the Awwwards Site of the Month and FWA Site of the Day honors.'
    ]
  },
  {
    id: 'neuralmind-ui',
    title: 'NeuralMind UI',
    category: 'AI & SaaS',
    subtitle: 'Futuristic real-time AI and SaaS data flow analytics platform',
    year: '2024',
    client: 'NeuralMind Corp',
    role: 'Founding Product Designer',
    accentColor: '#38485d',
    description: 'A dynamic AI data visualization platform. Represents neural network state-spaces in floating high-contrast glass panels.',
    longDescription: 'NeuralMind UI answers the hardest question in AI usability: how do you let engineers and operators visualize high-dimensional state weights in real time? Through an elegant blend of glowing particle vectors and crisp layered coordinates, the platform serves as a flight dashboard for machine learning operations.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDIm2tJnnaRxMeYxwnTTmzF4DDCxukry-mSDR9A-GT4HWJbwdzk4maYTnOyJjBAg0AYlTDenCE27SmTyL-R5y6UMrDh3ppPHKWsCpgds9HwyjVwXbHoQn-XCH21hfIcjSPJtgdiDNZciERblN3ZKgh-98LEBjAtA6dgwY5z3Mn9l1AN03PRmRQ6jPEUDsquossm1cUuE2pggMXcx0O-LJVQhFtoKQhxnQtavr1fC0KTIFJSbWlZaTiXj8Yd_PgDNJQgulIqYLgl9YU',
    tags: ['AI Interface', 'Data Visualization', 'D3.js integration', 'SaaS Architecture'],
    challenges: 'Visualizing thousands of nodes firing per second can crash standard browsers or cause serious cognitive fatigue. The challenge rested on grouping system outputs into intuitive visual streams via custom WebGL visual patterns.',
    outcomes: [
      'Rendered over 50,000 active neural connections at stable 60FPS on general mobile handsets.',
      'Simplified model tuning workflows, shortening client hyperparameter fine-tuning durations by 30%.',
      'Developed a responsive workspace utilizing customizable grid nodes.',
      'Recognized with the UX Design Award Gold for exceptional developer tooling interface work.'
    ]
  }
];

export const toolkitItems: ToolkitItem[] = [
  {
    name: 'Figma',
    category: 'Interface Design',
    iconName: 'Layout',
    description: 'Industry-standard vector layouts, collaborative Design Systems, and clickable mockups.'
  },
  {
    name: 'React',
    category: 'Architecture',
    iconName: 'Code',
    description: 'Component-driven, solid state-authoritative UI solutions built on TypeScript.'
  },
  {
    name: 'Framer Motion',
    category: 'Interactions',
    iconName: 'Sparkles',
    description: 'Choreographed physical micro-interactions and screen routing transitions.'
  },
  {
    name: 'Tailwind CSS',
    category: 'Styling System',
    iconName: 'Sliders',
    description: 'Utility-first presentation layout engine for crisp responsive designs.'
  }
];

export const tagsData = ['GSAP', 'Three.js', 'TypeScript', 'Adobe CC', 'Webflow', 'Blender'];
