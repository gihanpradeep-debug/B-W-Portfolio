import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  onScrollToWorks: () => void;
}

export default function Hero({ onScrollToWorks }: HeroProps) {
  return (
    <section className="min-h-screen flex items-center pt-28 pb-16 px-6 md:px-20 max-w-7xl mx-auto overflow-hidden relative">
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-12 items-center w-full relative z-10">
        
        {/* Left Side: Typography and Introductions */}
        <div className="xl:col-span-7 flex flex-col justify-center">
          <motion.span
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-block font-sans text-xs tracking-[0.25em] uppercase text-[#64748b] mb-6 font-bold"
          >
            Design & Development Portfolio
          </motion.span>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl leading-[1.05] tracking-[-0.04em] font-extrabold text-[#131313] mb-12 uppercase"
          >
            Creating <span className="text-outline text-slate-800">Digital</span> Experiences That People Remember.
          </motion.h1>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-start sm:items-center gap-8 justify-start"
          >
            <p className="font-sans text-base md:text-lg text-[#44474c] max-w-md leading-relaxed">
              Crafting high-end digital products with a focus on minimalist aesthetics and flawless functionality.
            </p>
            
            <button
              onClick={onScrollToWorks}
              className="group flex items-center gap-3 font-sans text-xs uppercase tracking-widest font-bold text-[#131313] hover:text-[#64748b] transition-all py-2"
            >
              View Selected Works
              <span className="p-2 rounded-full border border-[#131313]/10 group-hover:border-[#131313]/30 transition-transform group-hover:translate-x-1.5 duration-300">
                <ArrowRight className="w-4 h-4 text-[#131313]" />
              </span>
            </button>
          </motion.div>
        </div>

        {/* Right Side: Rotating Device / Frame Concept */}
        <div className="xl:col-span-5 flex justify-center xl:justify-end">
          <motion.div
            initial={{ opacity: 0, scale: 0.9, rotate: 12, x: 50 }}
            animate={{ opacity: 1, scale: 1, rotate: 6, x: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 80, delay: 0.4 }}
            whileHover={{ rotate: 0, scale: 1.04, transition: { duration: 0.5 } }}
            className="w-full max-w-[420px] aspect-[4/5] bg-white rounded-[32px] shadow-[0_24px_50px_rgba(0,0,0,0.06)] border border-[#131313]/5 p-6 cursor-pointer relative overflow-hidden"
          >
            <div className="w-full h-full rounded-[20px] overflow-hidden bg-slate-100 relative group">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAurzfJBDCh2fm-uR0GoPTA1g_7bGxkBfKUqbi7ihiVYF_MSe8KHsom8tj372ylWURF8I1VpNGqs4iaGfimGyEGN1WI1ho_1Dlf-k950yxmzhiqqXHxWZh9OiPdOEfHVbfdiOeufrVUJNMR8utxqj35LNxOj-IddYWUtjJVtRhkvn-VX2qwmbWxio_AENa35H-Leeh-Bh1pycCrhanJ8qNECPPujMTaLVkRXJHbOpC7upP5WPmHaxIB8JgiQCBy0s4K5iIn_8mbFZA"
                alt="UI FinTech Concept Design"
                className="w-full h-full object-cover opacity-90 transition-transform duration-1000 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              {/* Subtle glass Overlay simulating depth */}
              <div className="absolute inset-0 bg-gradient-to-t from-white/90 via-white/10 to-transparent flex flex-col justify-end p-8">
                <div className="backdrop-blur-md bg-white/40 p-4 rounded-2xl border border-white/60 shadow-sm">
                  <div className="h-2 w-16 bg-[#131313]/20 rounded-full mb-2"></div>
                  <div className="h-6 w-full bg-[#131313]/10 rounded-lg mb-2"></div>
                  <div className="h-4 w-2/3 bg-[#131313]/10 rounded-lg"></div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Decorative light atmospheric accents */}
      <div className="absolute top-[10%] right-[-10%] w-[500px] h-[500px] bg-[#b7c8e1]/10 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[0%] left-[-10%] w-[400px] h-[400px] bg-[#e3c199]/15 rounded-full blur-[100px] pointer-events-none z-0"></div>
    </section>
  );
}
